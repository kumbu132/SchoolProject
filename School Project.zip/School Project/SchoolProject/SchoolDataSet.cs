﻿namespace SchoolProject
{


    partial class SchoolDataSet
    {
    }
}

namespace SchoolProject.SchoolDataSetTableAdapters {
    
    
    public partial class DataTable1TableAdapter {
    }
}
